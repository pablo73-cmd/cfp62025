﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _061025_imprimir
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Método que define qué se imprime
        private void ImprimirTexto(object sender, PrintPageEventArgs e)
        {
            string texto = "¡Hola! Esto es una prueba de impresión en C#.";
            Font fuente = new Font("Arial", 12);
            float x = 100;
            float y = 100;

            e.Graphics.DrawString(texto, fuente, Brushes.Black, x, y);
        }

        // Botón para vista previa
        private void btnVistaPrevia_Click(object sender, EventArgs e)
        {
            PrintDocument printDoc = new PrintDocument();
            printDoc.PrintPage += ImprimirTexto;

            PrintPreviewDialog preview = new PrintPreviewDialog();
            preview.Document = printDoc;
            preview.ShowDialog();
        }

        // Botón para imprimir directamente
        private void btnImprimirDirecto_Click(object sender, EventArgs e)
        {
            PrintDocument printDoc = new PrintDocument();
            printDoc.PrintPage += ImprimirTexto;

            try
            {
                printDoc.Print();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al imprimir: " + ex.Message, "Error de impresión",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
