using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace _151025
{

    public partial class Form1 : Form
    {
        private string connectionString = "server=localhost;user=root;password=;database=quince;";

        public Form1()
        {
            InitializeComponent();
            CargarNombresImagenes();
        }

        private void CargarNombresImagenes()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT id, nombre FROM imagenes";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    cmbImagenes.DisplayMember = "nombre";
                    cmbImagenes.ValueMember = "id";
                    cmbImagenes.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar las im�genes: " + ex.Message);
            }
        }

        private void cmbImagenes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbImagenes.SelectedValue == null) return;

            int id = Convert.ToInt32(cmbImagenes.SelectedValue);

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT ruta FROM imagenes WHERE id = @id";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", id);
                    object result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        string ruta = result.ToString();
                        if (File.Exists(ruta))
                        {
                            pictureBox1.Image = Image.FromFile(ruta);
                        }
                        else
                        {
                            pictureBox1.Image = null;
                            MessageBox.Show("La imagen no se encuentra en la ruta especificada.");
                        }
                    }
                    else
                    {
                        pictureBox1.Image = null;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar la imagen: " + ex.Message);
            }
        }

        private void btnCargar_Click(object sender, EventArgs e)
        {
            CargarNombresImagenes();
        }

        private void btnCargar_Click_1(object sender, EventArgs e)
        {
            CargarNombresImagenes();
        }

        private void cmbImagenes_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (cmbImagenes.SelectedValue == null) return;

            int id = Convert.ToInt32(cmbImagenes.SelectedValue);

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT ruta FROM imagenes WHERE id = @id";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", id);
                    object result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        string ruta = result.ToString();
                        if (File.Exists(ruta))
                        {
                            pictureBox1.Image = Image.FromFile(ruta);
                        }
                        else
                        {
                            pictureBox1.Image = null;
                            MessageBox.Show("La imagen no se encuentra en la ruta especificada.");
                        }
                    }
                    else
                    {
                        pictureBox1.Image = null;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar la imagen: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.Show();
        }
    }
}
