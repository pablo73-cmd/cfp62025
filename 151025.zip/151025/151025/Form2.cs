﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace _151025
{
    public partial class Form2 : Form
    {
        
        private string connectionString = "server=localhost;user=root;password=;database=quince;";

        
        private string carpetaImagenes = Path.Combine(Application.StartupPath, "imagenes");

        public Form2()
        {
            InitializeComponent();

            // Crear la carpeta si no existe
            if (!Directory.Exists(carpetaImagenes))
                Directory.CreateDirectory(carpetaImagenes);

            CargarNombresImagenes();
        }

        
        private void CargarNombresImagenes()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT id, nombre FROM imagenes ORDER BY nombre";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    cmbImagenes.DisplayMember = "nombre";
                    cmbImagenes.ValueMember = "id";
                    cmbImagenes.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar las imágenes: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        
        private void cmbImagenes_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        
        private void btnSeleccionar_Click(object sender, EventArgs e)
        {

        }

        
        private void btnGuardar_Click(object sender, EventArgs e)
        {
        }

        
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            pictureBox1.Image?.Dispose();
            base.OnFormClosed(e);
        }

        private void cmbImagenes_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (cmbImagenes.SelectedValue == null || cmbImagenes.SelectedValue == DBNull.Value) return;

            int id = Convert.ToInt32(cmbImagenes.SelectedValue);

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT ruta FROM imagenes WHERE id = @id";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", id);
                    object result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        string ruta = result.ToString();
                        if (File.Exists(ruta))
                        {
                            pictureBox1.Image?.Dispose(); // Liberar imagen anterior
                            pictureBox1.Image = Image.FromFile(ruta);
                        }
                        else
                        {
                            pictureBox1.Image = null;
                            MessageBox.Show("La imagen no se encuentra en la ruta:\n" + ruta, "Archivo no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        pictureBox1.Image = null;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar la imagen: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnSeleccionar_Click_1(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Imágenes|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
                ofd.Title = "Seleccionar una imagen";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    // Previsualizar
                    pictureBox1.Image?.Dispose();
                    pictureBox1.Image = Image.FromFile(ofd.FileName);

                    // Opcional: sugerir nombre basado en el archivo
                    txtNombre.Text = Path.GetFileNameWithoutExtension(ofd.FileName);
                }
            }
        }

        private void btnGuardar_Click_1(object sender, EventArgs e)
        {

            if (pictureBox1.Image == null)
            {
                MessageBox.Show("Primero seleccione una imagen.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string nombre = txtNombre.Text.Trim();
            if (string.IsNullOrEmpty(nombre))
            {
                MessageBox.Show("Ingrese un nombre para la imagen.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Obtener ruta original (del OpenFileDialog no se guarda, así que usamos la del PictureBox)
            // Pero como no guardamos la ruta original, copiaremos la imagen a nuestra carpeta
            try
            {
                // Generar nombre único para evitar colisiones
                string extension = ".jpg"; // puedes detectar la extensión real si lo deseas
                string nombreArchivo = $"{Guid.NewGuid()}{extension}";
                string rutaGuardada = Path.Combine(carpetaImagenes, nombreArchivo);

                // Guardar la imagen en la carpeta
                pictureBox1.Image.Save(rutaGuardada, System.Drawing.Imaging.ImageFormat.Jpeg);

                // Guardar en la base de datos
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO imagenes (nombre, ruta) VALUES (@nombre, @ruta)";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@nombre", nombre);
                    cmd.Parameters.AddWithValue("@ruta", rutaGuardada); // Ruta absoluta

                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Imagen guardada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Recargar lista
                CargarNombresImagenes();

                // Limpiar
                txtNombre.Clear();
                pictureBox1.Image?.Dispose();
                pictureBox1.Image = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar la imagen: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}