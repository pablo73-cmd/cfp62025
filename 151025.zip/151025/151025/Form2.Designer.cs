﻿namespace _151025
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSeleccionar = new Button();
            btnGuardar = new Button();
            txtNombre = new TextBox();
            pictureBox1 = new PictureBox();
            cmbImagenes = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnSeleccionar
            // 
            btnSeleccionar.Location = new Point(225, 69);
            btnSeleccionar.Name = "btnSeleccionar";
            btnSeleccionar.Size = new Size(75, 23);
            btnSeleccionar.TabIndex = 0;
            btnSeleccionar.Text = "seleccionar";
            btnSeleccionar.UseVisualStyleBackColor = true;
            btnSeleccionar.Click += btnSeleccionar_Click_1;
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(226, 174);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 23);
            btnGuardar.TabIndex = 1;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click_1;
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(242, 123);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(100, 23);
            txtNombre.TabIndex = 2;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(444, 120);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(222, 137);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // cmbImagenes
            // 
            cmbImagenes.FormattingEnabled = true;
            cmbImagenes.Location = new Point(34, 120);
            cmbImagenes.Name = "cmbImagenes";
            cmbImagenes.Size = new Size(121, 23);
            cmbImagenes.TabIndex = 4;
            cmbImagenes.SelectedIndexChanged += cmbImagenes_SelectedIndexChanged_1;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(cmbImagenes);
            Controls.Add(pictureBox1);
            Controls.Add(txtNombre);
            Controls.Add(btnGuardar);
            Controls.Add(btnSeleccionar);
            Name = "Form2";
            Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSeleccionar;
        private Button btnGuardar;
        private TextBox txtNombre;
        private PictureBox pictureBox1;
        private ComboBox cmbImagenes;
    }
}