using System;
using System.Data;
using System.Windows.Forms;
namespace _290925
{


    public partial class Form1 : Form
    {
        private ConexionBD conexion;
        private DataTable datos;
        private int registroActual = 0;
        private bool modoNuevo = false;
        private bool modoEdicion = false;


        public Form1()
        {
            InitializeComponent();
            conexion = new ConexionBD();
        }


        private void CargarDatos()
        {
            modoNuevo = false;
            string consulta = "SELECT * FROM clientes";
            datos = conexion.ObtenerDatos(consulta);

            if (datos.Rows.Count > 0)
            {
                registroActual = 0;
                MostrarRegistroActual();
            }
            else
            {
                MessageBox.Show("No hay datos en la tabla");
            }
        }


        private void MostrarRegistroActual()
        {
            modoNuevo = false;
            modoEdicion = false;
            if (datos.Rows.Count == 0) return;

            DataRow fila = datos.Rows[registroActual];


            txtId.Text = fila["id"].ToString();
            txtNombre.Text = fila["nombre"].ToString();
            txtEmail.Text = fila["email"].ToString();


            lblContador.Text = $"Registro {registroActual + 1} de {datos.Rows.Count}";

            btnAnterior.Enabled = (registroActual > 0);
            btnSiguiente.Enabled = (registroActual < datos.Rows.Count - 1);
        }


        private void btnSiguiente_Click(object sender, EventArgs e)
        {

        }


        private void btnAnterior_Click(object sender, EventArgs e)
        {

        }


        private void btnCargarDatos_Click(object sender, EventArgs e)
        {

        }

        private void btnCargarDatos_Click_1(object sender, EventArgs e)
        {
            CargarDatos();
        }

        private void btnSiguiente_Click_1(object sender, EventArgs e)
        {
            if (registroActual < datos.Rows.Count - 1)
            {
                registroActual++;
                MostrarRegistroActual();
            }
        }

        private void btnAnterior_Click_1(object sender, EventArgs e)
        {
            if (registroActual > 0)
            {
                registroActual--;
                MostrarRegistroActual();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //  CargarDatos();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {

            modoNuevo = true;
            txtNombre.ReadOnly = false;
            txtEmail.ReadOnly = false;
            txtId.Clear();
            txtNombre.Clear();
            txtEmail.Clear();
            txtNombre.Focus();

            btnAnterior.Enabled = false;
            btnSiguiente.Enabled = false;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {


            /*
            if (string.IsNullOrWhiteSpace(txtNombre.Text) || string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Por favor, complete todos los campos.");
                return;
            }

            if (modoNuevo)
            {
                bool exito = conexion.InsertarCliente(txtNombre.Text, txtEmail.Text);
                if (exito)
                {
                    MessageBox.Show("Cliente insertado correctamente.");
                    CargarDatos();
                    modoNuevo = false;
                }
            }
            else
            {

                MessageBox.Show("Modo edici�n no implementado a�n.");
            }*/


            if (string.IsNullOrWhiteSpace(txtNombre.Text) || string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Por favor, complete todos los campos.");
                return;
            }

            if (modoNuevo)
            {
                bool exito = conexion.InsertarCliente(txtNombre.Text, txtEmail.Text);
                if (exito)
                {
                    MessageBox.Show("Cliente insertado correctamente.");
                    txtNombre.ReadOnly = true;
                    txtEmail.ReadOnly = true; 
                    CargarDatos();
                }
            }
            else if (modoEdicion)
            {
                if (!int.TryParse(txtId.Text, out int id))
                {
                    MessageBox.Show("ID inv�lido.");
                    return;
                }

                bool exito = conexion.ActualizarCliente(id, txtNombre.Text, txtEmail.Text);
                if (exito)
                {
                    MessageBox.Show("Cliente actualizado correctamente.");
                    txtNombre.ReadOnly = true;
                    txtEmail.ReadOnly = true;
                    CargarDatos();
                }
            }
            else
            {
                MessageBox.Show("No hay cambios pendientes.");
            }
        }



        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (datos.Rows.Count == 0)
            {
                MessageBox.Show("No hay registros para editar.");
                return;
            }

            modoEdicion = true;
            txtNombre.ReadOnly = false;
            txtEmail.ReadOnly = false;
            txtNombre.Focus();

            btnAnterior.Enabled = false;
            btnSiguiente.Enabled = false;
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
        
            if (datos.Rows.Count == 0)
            {
                MessageBox.Show("No hay registros para eliminar.");
                return;
            }

            if (MessageBox.Show("�Est� seguro de que desea eliminar este cliente?",
                                "Confirmar eliminaci�n",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                if (!int.TryParse(txtId.Text, out int id))
                {
                    MessageBox.Show("ID inv�lido.");
                    return;
                }

                bool exito = conexion.EliminarCliente(id);
                if (exito)
                {
                    MessageBox.Show("Cliente eliminado correctamente.");
                    CargarDatos(); // Recarga los datos
                }
            }
        }
    }
    }



