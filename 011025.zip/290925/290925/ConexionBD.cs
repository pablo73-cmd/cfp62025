﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace _290925
{
    public class ConexionBD
    {
      
        private string conexion = "Server=localhost;Database=empresa2;Uid=root;Pwd=;";

       
        public DataTable ObtenerDatos(string consultaSQL)
        {
            DataTable tabla = new DataTable();
            /*
             MySqlConnection conectar = new MySqlConnection(conexion);
            conectar.Open();
            MySqlCommand comando = new MySqlCommand(consultaSQL, conectar);
            MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
            adaptador.Fill(tabla);
             */
            try
            {
                using (MySqlConnection conectar = new MySqlConnection(conexion))
                {
                    conectar.Open();
                    using (MySqlCommand comando = new MySqlCommand(consultaSQL, conectar))
                    {
                        using (MySqlDataAdapter adaptador = new MySqlDataAdapter(comando))
                        {
                            adaptador.Fill(tabla);
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error de base de datos: " + ex.Message);
            }

            return tabla;
        }
        public bool InsertarCliente(string nombre, string email)
        {
            string consulta = "INSERT INTO clientes (nombre, email) VALUES (@nombre, @email)";

            try
            {
                using (MySqlConnection conectar = new MySqlConnection(conexion))
                {
                    conectar.Open();
                    using (MySqlCommand comando = new MySqlCommand(consulta, conectar))
                    {
                        comando.Parameters.AddWithValue("@nombre", nombre);
                        comando.Parameters.AddWithValue("@email", email);
                        int filasAfectadas = comando.ExecuteNonQuery();
                        return filasAfectadas > 0;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error al insertar: " + ex.Message);
                return false;
            }
        }

        public bool ActualizarCliente(int id, string nombre, string email)
        {
            string consulta = "UPDATE clientes SET nombre = @nombre, email = @email WHERE id = @id";

            try
            {
                using (MySqlConnection conectar = new MySqlConnection(conexion))
                {
                    conectar.Open();
                    using (MySqlCommand comando = new MySqlCommand(consulta, conectar))
                    {
                        comando.Parameters.AddWithValue("@id", id);
                        comando.Parameters.AddWithValue("@nombre", nombre);
                        comando.Parameters.AddWithValue("@email", email);
                        int filasAfectadas = comando.ExecuteNonQuery();
                        return filasAfectadas > 0;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error al actualizar: " + ex.Message);
                return false;
            }
        }

        public bool EliminarCliente(int id)
        {
            string consulta = "DELETE FROM clientes WHERE id = @id";

            try
            {
                using (MySqlConnection conectar = new MySqlConnection(conexion))
                {
                    conectar.Open();
                    using (MySqlCommand comando = new MySqlCommand(consulta, conectar))
                    {
                        comando.Parameters.AddWithValue("@id", id);
                        int filasAfectadas = comando.ExecuteNonQuery();
                        return filasAfectadas > 0;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error al eliminar: " + ex.Message);
                return false;
            }
        }


    }

    }

