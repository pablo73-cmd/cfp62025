using System.Windows.Forms;

namespace WinFormsApp30
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_mostrar_Click(object sender, EventArgs e)
        {
            rch_texto.AppendText("Hola que tal como te va.....");
        }

        private void btn_limpiar_Click(object sender, EventArgs e)
        {
            rch_texto.Clear();
        }

        private void btn_guardar_Click(object sender, EventArgs e)
        {
            SaveFileDialog guardar = new SaveFileDialog();
            guardar.Filter = "Archivos de tipo RTF(*.rtf)|*.rtf | Archivos de tipo txt(*.txt)|*.txt";


            if (guardar.ShowDialog() == DialogResult.OK)
            {
                //richTextBox1.SaveFile("archivo.txt", RichTextBoxStreamType.PlainText);

                rch_texto.SaveFile(guardar.FileName, RichTextBoxStreamType.PlainText);
            }
        }

        private void saveFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void btn_abrirArc_Click(object sender, EventArgs e)
        {
            OpenFileDialog abrirnuevo = new OpenFileDialog();
            abrirnuevo.Filter = "Archivos de tipo RTF(*.rtf)|*.rtf | Archivos de tipo txt(*.txt)|*.txt";
            abrirnuevo.Title = "Abrir Archivo";
            if (abrirnuevo.ShowDialog() == DialogResult.OK) {
                
                rch_texto.LoadFile(abrirnuevo.FileName, RichTextBoxStreamType.PlainText);
                //rch_texto.LoadFile(abrirnuevo.FileName, RichTextBoxStreamType.RichText);
            }
        
        }
    }
}
