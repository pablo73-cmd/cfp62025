﻿namespace WinFormsApp30
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_mostrar = new Button();
            rch_texto = new RichTextBox();
            btn_limpiar = new Button();
            btn_guardar = new Button();
            btn_abrirArc = new Button();
            SuspendLayout();
            // 
            // btn_mostrar
            // 
            btn_mostrar.Location = new Point(112, 176);
            btn_mostrar.Name = "btn_mostrar";
            btn_mostrar.Size = new Size(129, 23);
            btn_mostrar.TabIndex = 0;
            btn_mostrar.Text = "Mostrar Texto";
            btn_mostrar.UseVisualStyleBackColor = true;
            btn_mostrar.Click += btn_mostrar_Click;
            // 
            // rch_texto
            // 
            rch_texto.Location = new Point(379, 80);
            rch_texto.Name = "rch_texto";
            rch_texto.Size = new Size(252, 211);
            rch_texto.TabIndex = 1;
            rch_texto.Text = "";
            // 
            // btn_limpiar
            // 
            btn_limpiar.Location = new Point(116, 214);
            btn_limpiar.Name = "btn_limpiar";
            btn_limpiar.Size = new Size(125, 23);
            btn_limpiar.TabIndex = 2;
            btn_limpiar.Text = "Limpiar Texto";
            btn_limpiar.UseVisualStyleBackColor = true;
            btn_limpiar.Click += btn_limpiar_Click;
            // 
            // btn_guardar
            // 
            btn_guardar.Location = new Point(116, 257);
            btn_guardar.Name = "btn_guardar";
            btn_guardar.Size = new Size(118, 23);
            btn_guardar.TabIndex = 3;
            btn_guardar.Text = "Guardar Texto";
            btn_guardar.UseVisualStyleBackColor = true;
            btn_guardar.Click += btn_guardar_Click;
            // 
            // btn_abrirArc
            // 
            btn_abrirArc.Location = new Point(116, 293);
            btn_abrirArc.Name = "btn_abrirArc";
            btn_abrirArc.Size = new Size(118, 23);
            btn_abrirArc.TabIndex = 4;
            btn_abrirArc.Text = "Abrir Archivo";
            btn_abrirArc.UseVisualStyleBackColor = true;
            btn_abrirArc.Click += btn_abrirArc_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btn_abrirArc);
            Controls.Add(btn_guardar);
            Controls.Add(btn_limpiar);
            Controls.Add(rch_texto);
            Controls.Add(btn_mostrar);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btn_mostrar;
        private RichTextBox rch_texto;
        private Button btn_limpiar;
        private Button btn_guardar;
        private Button btn_abrirArc;
    }
}
