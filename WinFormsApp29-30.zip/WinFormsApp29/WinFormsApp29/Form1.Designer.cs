﻿namespace WinFormsApp29
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            menuStrip1 = new MenuStrip();
            inicioToolStripMenuItem = new ToolStripMenuItem();
            abrirVentanaToolStripMenuItem = new ToolStripMenuItem();
            cerrarProgramaToolStripMenuItem = new ToolStripMenuItem();
            ayudaToolStripMenuItem = new ToolStripMenuItem();
            acercaDeToolStripMenuItem = new ToolStripMenuItem();
            contextMenuStrip1 = new ContextMenuStrip(components);
            realizadoPorPabloToolStripMenuItem = new ToolStripMenuItem();
            button1 = new Button();
            contextMenuStrip2 = new ContextMenuStrip(components);
            nuevasOpcionesToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            contextMenuStrip1.SuspendLayout();
            contextMenuStrip2.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { inicioToolStripMenuItem, ayudaToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // inicioToolStripMenuItem
            // 
            inicioToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { abrirVentanaToolStripMenuItem, cerrarProgramaToolStripMenuItem });
            inicioToolStripMenuItem.Name = "inicioToolStripMenuItem";
            inicioToolStripMenuItem.Size = new Size(48, 20);
            inicioToolStripMenuItem.Text = "inicio";
            // 
            // abrirVentanaToolStripMenuItem
            // 
            abrirVentanaToolStripMenuItem.Name = "abrirVentanaToolStripMenuItem";
            abrirVentanaToolStripMenuItem.Size = new Size(159, 22);
            abrirVentanaToolStripMenuItem.Text = "abrir ventana";
            abrirVentanaToolStripMenuItem.Click += abrirVentanaToolStripMenuItem_Click;
            // 
            // cerrarProgramaToolStripMenuItem
            // 
            cerrarProgramaToolStripMenuItem.Name = "cerrarProgramaToolStripMenuItem";
            cerrarProgramaToolStripMenuItem.Size = new Size(159, 22);
            cerrarProgramaToolStripMenuItem.Text = "cerrar programa";
            cerrarProgramaToolStripMenuItem.Click += cerrarProgramaToolStripMenuItem_Click;
            // 
            // ayudaToolStripMenuItem
            // 
            ayudaToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { acercaDeToolStripMenuItem });
            ayudaToolStripMenuItem.Name = "ayudaToolStripMenuItem";
            ayudaToolStripMenuItem.Size = new Size(53, 20);
            ayudaToolStripMenuItem.Text = "Ayuda";
            // 
            // acercaDeToolStripMenuItem
            // 
            acercaDeToolStripMenuItem.Name = "acercaDeToolStripMenuItem";
            acercaDeToolStripMenuItem.Size = new Size(129, 22);
            acercaDeToolStripMenuItem.Text = "Acerca de ";
            acercaDeToolStripMenuItem.Click += acercaDeToolStripMenuItem_Click;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { realizadoPorPabloToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(179, 26);
            // 
            // realizadoPorPabloToolStripMenuItem
            // 
            realizadoPorPabloToolStripMenuItem.Name = "realizadoPorPabloToolStripMenuItem";
            realizadoPorPabloToolStripMenuItem.Size = new Size(178, 22);
            realizadoPorPabloToolStripMenuItem.Text = "Realizado por Pablo";
            // 
            // button1
            // 
            button1.ContextMenuStrip = contextMenuStrip2;
            button1.Location = new Point(488, 70);
            button1.Name = "button1";
            button1.Size = new Size(251, 23);
            button1.TabIndex = 1;
            button1.Text = "más opciones con menu contextual";
            button1.UseVisualStyleBackColor = true;
            // 
            // contextMenuStrip2
            // 
            contextMenuStrip2.Items.AddRange(new ToolStripItem[] { nuevasOpcionesToolStripMenuItem });
            contextMenuStrip2.Name = "contextMenuStrip2";
            contextMenuStrip2.Size = new Size(165, 26);
            // 
            // nuevasOpcionesToolStripMenuItem
            // 
            nuevasOpcionesToolStripMenuItem.Name = "nuevasOpcionesToolStripMenuItem";
            nuevasOpcionesToolStripMenuItem.Size = new Size(164, 22);
            nuevasOpcionesToolStripMenuItem.Text = "Nuevas opciones";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            ContextMenuStrip = contextMenuStrip1;
            Controls.Add(button1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            contextMenuStrip1.ResumeLayout(false);
            contextMenuStrip2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem inicioToolStripMenuItem;
        private ToolStripMenuItem abrirVentanaToolStripMenuItem;
        private ToolStripMenuItem cerrarProgramaToolStripMenuItem;
        private ToolStripMenuItem ayudaToolStripMenuItem;
        private ToolStripMenuItem acercaDeToolStripMenuItem;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem realizadoPorPabloToolStripMenuItem;
        private Button button1;
        private ContextMenuStrip contextMenuStrip2;
        private ToolStripMenuItem nuevasOpcionesToolStripMenuItem;
    }
}
