﻿namespace WinFormsApp29
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            toolStrip1 = new ToolStrip();
            toolStripButton1 = new ToolStripButton();
            toolStripSeparator1 = new ToolStripSeparator();
            toolStripSplitButton1 = new ToolStripSplitButton();
            otraVentanaToolStripMenuItem = new ToolStripMenuItem();
            toolStripDropDownButton1 = new ToolStripDropDownButton();
            nuevaVentanaToolStripMenuItem = new ToolStripMenuItem();
            otraVentanaMasToolStripMenuItem = new ToolStripMenuItem();
            otraVentanaToolStripMenuItem1 = new ToolStripMenuItem();
            toolStripLabel1 = new ToolStripLabel();
            toolStripComboBox1 = new ToolStripComboBox();
            txt_pais = new TextBox();
            toolStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // toolStrip1
            // 
            toolStrip1.ImageScalingSize = new Size(32, 32);
            toolStrip1.Items.AddRange(new ToolStripItem[] { toolStripButton1, toolStripSeparator1, toolStripSplitButton1, toolStripDropDownButton1, toolStripLabel1, toolStripComboBox1 });
            toolStrip1.Location = new Point(0, 0);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Size = new Size(800, 39);
            toolStrip1.TabIndex = 0;
            toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            toolStripButton1.DisplayStyle = ToolStripItemDisplayStyle.Image;
            toolStripButton1.Image = (Image)resources.GetObject("toolStripButton1.Image");
            toolStripButton1.ImageTransparentColor = Color.Magenta;
            toolStripButton1.Name = "toolStripButton1";
            toolStripButton1.Size = new Size(36, 36);
            toolStripButton1.Text = "toolStripButton1";
            toolStripButton1.ToolTipText = "acceso al león";
            toolStripButton1.Click += toolStripButton1_Click;
            // 
            // toolStripSeparator1
            // 
            toolStripSeparator1.Name = "toolStripSeparator1";
            toolStripSeparator1.Size = new Size(6, 39);
            // 
            // toolStripSplitButton1
            // 
            toolStripSplitButton1.DisplayStyle = ToolStripItemDisplayStyle.Image;
            toolStripSplitButton1.DropDownItems.AddRange(new ToolStripItem[] { otraVentanaToolStripMenuItem });
            toolStripSplitButton1.Image = (Image)resources.GetObject("toolStripSplitButton1.Image");
            toolStripSplitButton1.ImageTransparentColor = Color.Magenta;
            toolStripSplitButton1.Name = "toolStripSplitButton1";
            toolStripSplitButton1.Size = new Size(48, 36);
            toolStripSplitButton1.Text = "Gallina";
            toolStripSplitButton1.ToolTipText = "acceso a la gallina";
            // 
            // otraVentanaToolStripMenuItem
            // 
            otraVentanaToolStripMenuItem.Name = "otraVentanaToolStripMenuItem";
            otraVentanaToolStripMenuItem.Size = new Size(140, 22);
            otraVentanaToolStripMenuItem.Text = "otra ventana";
            otraVentanaToolStripMenuItem.Click += otraVentanaToolStripMenuItem_Click;
            // 
            // toolStripDropDownButton1
            // 
            toolStripDropDownButton1.DisplayStyle = ToolStripItemDisplayStyle.Image;
            toolStripDropDownButton1.DropDownItems.AddRange(new ToolStripItem[] { nuevaVentanaToolStripMenuItem, otraVentanaMasToolStripMenuItem });
            toolStripDropDownButton1.Image = (Image)resources.GetObject("toolStripDropDownButton1.Image");
            toolStripDropDownButton1.ImageTransparentColor = Color.Magenta;
            toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            toolStripDropDownButton1.Size = new Size(45, 36);
            toolStripDropDownButton1.Text = "Panda 1.0";
            toolStripDropDownButton1.TextAlign = ContentAlignment.TopCenter;
            toolStripDropDownButton1.TextImageRelation = TextImageRelation.TextAboveImage;
            toolStripDropDownButton1.ToolTipText = "Panda";
            // 
            // nuevaVentanaToolStripMenuItem
            // 
            nuevaVentanaToolStripMenuItem.Name = "nuevaVentanaToolStripMenuItem";
            nuevaVentanaToolStripMenuItem.Size = new Size(109, 22);
            nuevaVentanaToolStripMenuItem.Text = "abajo";
            nuevaVentanaToolStripMenuItem.Click += nuevaVentanaToolStripMenuItem_Click;
            // 
            // otraVentanaMasToolStripMenuItem
            // 
            otraVentanaMasToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { otraVentanaToolStripMenuItem1 });
            otraVentanaMasToolStripMenuItem.Name = "otraVentanaMasToolStripMenuItem";
            otraVentanaMasToolStripMenuItem.Size = new Size(109, 22);
            otraVentanaMasToolStripMenuItem.Text = "al lado";
            // 
            // otraVentanaToolStripMenuItem1
            // 
            otraVentanaToolStripMenuItem1.Name = "otraVentanaToolStripMenuItem1";
            otraVentanaToolStripMenuItem1.Size = new Size(140, 22);
            otraVentanaToolStripMenuItem1.Text = "otra ventana";
            otraVentanaToolStripMenuItem1.Click += otraVentanaToolStripMenuItem1_Click;
            // 
            // toolStripLabel1
            // 
            toolStripLabel1.Name = "toolStripLabel1";
            toolStripLabel1.Size = new Size(60, 36);
            toolStripLabel1.Text = "Copyright";
            toolStripLabel1.TextAlign = ContentAlignment.BottomCenter;
            toolStripLabel1.TextImageRelation = TextImageRelation.ImageAboveText;
            // 
            // toolStripComboBox1
            // 
            toolStripComboBox1.Items.AddRange(new object[] { "Argentina", "Brasil", "Chile" });
            toolStripComboBox1.Name = "toolStripComboBox1";
            toolStripComboBox1.Size = new Size(121, 39);
            toolStripComboBox1.Text = "Seleccione";
            toolStripComboBox1.ToolTipText = "Seleccione un pais ";
            toolStripComboBox1.DropDown += toolStripComboBox1_Click_2;
            toolStripComboBox1.Click += toolStripComboBox1_Click_2;
            // 
            // txt_pais
            // 
            txt_pais.Location = new Point(178, 134);
            txt_pais.Name = "txt_pais";
            txt_pais.Size = new Size(168, 23);
            txt_pais.TabIndex = 1;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txt_pais);
            Controls.Add(toolStrip1);
            Name = "Form2";
            Text = "Form2";
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ToolStrip toolStrip1;
        private ToolStripButton toolStripButton1;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripSplitButton toolStripSplitButton1;
        private ToolStripMenuItem otraVentanaToolStripMenuItem;
        private ToolStripDropDownButton toolStripDropDownButton1;
        private ToolStripMenuItem nuevaVentanaToolStripMenuItem;
        private ToolStripMenuItem otraVentanaMasToolStripMenuItem;
        private ToolStripMenuItem otraVentanaToolStripMenuItem1;
        private ToolStripLabel toolStripLabel1;
        private ToolStripComboBox toolStripComboBox1;
        private TextBox txt_pais;
    }
}