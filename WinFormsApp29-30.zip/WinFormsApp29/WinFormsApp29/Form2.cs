﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp29
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Form volver = new Form1();
            volver.Show();
            this.Hide();

        }

        private void otraVentanaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form acerca = new Form3();
            acerca.Show();
            this.Hide();
        }

        private void nuevaVentanaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void otraVentanaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hecho en Argentina", "Arbol Software", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripComboBox1_Drop_Down(object sender, EventArgs e)
        {
            if (toolStripComboBox1.SelectedItem != null)
            {
                txt_pais.Text = toolStripComboBox1.SelectedItem.ToString();
            }
        }

        private void toolStripComboBox1_Click_2(object sender, EventArgs e)
        {
            if (toolStripComboBox1.SelectedItem != null)
            {
                txt_pais.Text = toolStripComboBox1.SelectedItem.ToString();
            }
        }
    }
}
