using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
namespace WinFormsApp32
{
   

   
        public partial class Form1 : Form
        {
            public Form1()
            {
                InitializeComponent();
                CargarMiniaturas(@"C:\imagenes"); // Ruta de las im�genes
            }

            private void CargarMiniaturas(string rutaCarpeta)
            {
                // Configuraci�n del DataGridView
                dataGridView1.RowTemplate.Height = 100;
                dataGridView1.ColumnHeadersVisible = false;
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;

                // Columna de imagen
                DataGridViewImageColumn columnaImagen = new DataGridViewImageColumn();
                columnaImagen.HeaderText = "Miniatura";
                columnaImagen.ImageLayout = DataGridViewImageCellLayout.Zoom;
                dataGridView1.Columns.Add(columnaImagen);

                // Columna de nombre
                dataGridView1.Columns.Add("NombreArchivo", "Nombre del archivo");

                // Cargar im�genes
                string[] archivos = Directory.GetFiles(rutaCarpeta, "*.*")
                    ?? Array.Empty<string>();

                foreach (string archivo in archivos)
                {
                    if (archivo.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase) ||
                        archivo.EndsWith(".png", StringComparison.OrdinalIgnoreCase) ||
                        archivo.EndsWith(".jpeg", StringComparison.OrdinalIgnoreCase) ||
                        archivo.EndsWith(".bmp", StringComparison.OrdinalIgnoreCase))
                    {
                        Image miniatura = Image.FromFile(archivo);
                        dataGridView1.Rows.Add(miniatura, Path.GetFileName(archivo));
                    }
                }
            }
        }
    }


