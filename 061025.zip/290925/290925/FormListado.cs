﻿using System;
using System.Data;
using System.Windows.Forms;

namespace _290925
{
    public partial class FormListado : Form
    {
        private ConexionBD conexion;

        public FormListado()
        {
            InitializeComponent();
            conexion = new ConexionBD();

            dataGridViewClientes.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font(dataGridViewClientes.Font, System.Drawing.FontStyle.Bold);
            CargarTodosLosClientes();
        }




        private void CargarTodosLosClientes()
        {
            string consulta = "SELECT id AS CARNET, nombre AS Nombre, email AS CORREO FROM clientes";
            DataTable datos = conexion.ObtenerDatos(consulta);
            dataGridViewClientes.DataSource = datos; //aca relleno el datagridview


            dataGridViewClientes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;


            dataGridViewClientes.Columns["CARNET"].Width = 70; // anchos personalizados
            dataGridViewClientes.Columns["CORREO"].Width = 250; // anchos personalizados 


            dataGridViewClientes.Columns["Nombre"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill; // rellena con lo que queda
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {

        }
    }
}
    
