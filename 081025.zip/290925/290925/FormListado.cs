﻿using System;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace _290925
{
    public partial class FormListado : Form
    {
        private ConexionBD conexion;
        private PrintDocument printDocument;

        public FormListado()
        {
            InitializeComponent();
            conexion = new ConexionBD();

            dataGridViewClientes.ColumnHeadersDefaultCellStyle.Font = new Font(dataGridViewClientes.Font, FontStyle.Bold);
            CargarTodosLosClientes();

            // Configurar PrintDocument
            printDocument = new PrintDocument();
            printDocument.PrintPage += PrintDocument_PrintPage;
        }

        private void CargarTodosLosClientes()
        {
            string consulta = "SELECT id AS CARNET, nombre AS Nombre, email AS CORREO FROM clientes";
            DataTable datos = conexion.ObtenerDatos(consulta);
            dataGridViewClientes.DataSource = datos;

            dataGridViewClientes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
            dataGridViewClientes.Columns["CARNET"].Width = 70;
            dataGridViewClientes.Columns["CORREO"].Width = 250;
            dataGridViewClientes.Columns["Nombre"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            printDialog.Document = printDocument;

            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                printDocument.Print();
            }
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            // Configuración de impresión
            float margenIzquierdo = e.MarginBounds.Left;
            float margenSuperior = e.MarginBounds.Top;
            float anchoDisponible = e.MarginBounds.Width;

            // Fuente para el encabezado
            Font fuenteEncabezado = new Font("Arial", 16, FontStyle.Bold);
            Font fuenteColumnas = new Font("Arial", 10, FontStyle.Bold);
            Font fuenteDatos = new Font("Arial", 10, FontStyle.Regular);

            // Dibujar encabezado
            string encabezado = "Agenda de Clientes";
            SizeF tamanoEncabezado = e.Graphics.MeasureString(encabezado, fuenteEncabezado);
            float xEncabezado = margenIzquierdo + (anchoDisponible - tamanoEncabezado.Width) / 2;
            e.Graphics.DrawString(encabezado, fuenteEncabezado, Brushes.Black, xEncabezado, margenSuperior);
            float yActual = margenSuperior + tamanoEncabezado.Height + 10;

            // Anchos de columnas 
            float[] anchosColumnas = { 70, 200, 250 }; // Ajusta según el contenido
            string[] titulos = { "CARNET", "Nombre", "CORREO" };

            // Dibujar encabezados de columnas
            float x = margenIzquierdo;
            for (int i = 0; i < dataGridViewClientes.Columns.Count; i++)
            {
                e.Graphics.DrawString(titulos[i], fuenteColumnas, Brushes.Black, x, yActual);
                x += anchosColumnas[i];
            }
            yActual += fuenteColumnas.GetHeight(e.Graphics) + 5;

            // Dibujar filas
            foreach (DataGridViewRow fila in dataGridViewClientes.Rows)
            {
                if (fila.IsNewRow) continue; // Saltar la fila de nueva entrada

                x = margenIzquierdo;
                for (int i = 0; i < dataGridViewClientes.Columns.Count; i++)
                {
                    string valor = fila.Cells[i].Value?.ToString() ?? "";
                    e.Graphics.DrawString(valor, fuenteDatos, Brushes.Black, x, yActual);
                    x += anchosColumnas[i];
                }
                yActual += fuenteDatos.GetHeight(e.Graphics);

                // Verificar si hay que continuar en otra página
                if (yActual > e.MarginBounds.Bottom)
                {
                    e.HasMorePages = true;
                    return;
                }
            }

            e.HasMorePages = false;
        }
    }
}
