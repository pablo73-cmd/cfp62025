using System;
using System.Data;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Printing;
using System.Drawing.Imaging; 

namespace _290925
{
    public partial class Form1 : Form
    {
        private ConexionBD conexion;
        private DataTable datos;
        private int registroActual = 0;
        private bool modoNuevo = false;
        private bool modoEdicion = false;
        private PrintDocument printDocument;

        public Form1()
        {
            InitializeComponent();

            conexion = new ConexionBD();

            printDocument = new PrintDocument();
            printDocument.PrintPage += PrintDocument_PrintPage;
        }

        /* private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
         {
             // Configuraci�n b�sica
             Graphics g = e.Graphics;
             Font fuenteTitulo = new Font("Arial", 18, FontStyle.Bold);
             Font fuenteEtiqueta = new Font("Arial", 12, FontStyle.Bold);
             Font fuenteValor = new Font("Arial", 12, FontStyle.Regular);

             float margenIzq = e.MarginBounds.Left;
             float margenTop = e.MarginBounds.Top;
             float y = margenTop;

             // T�tulo centrado
             string titulo = "REGISTRO DE CLIENTE";
             SizeF tamanoTitulo = g.MeasureString(titulo, fuenteTitulo);
             float xTitulo = margenIzq + (e.MarginBounds.Width - tamanoTitulo.Width) / 2;
             g.DrawString(titulo, fuenteTitulo, Brushes.Black, xTitulo, y);
             y += tamanoTitulo.Height + 20;

             // Datos del cliente actual
             string id = txtId.Text;
             string nombre = txtNombre.Text;
             string email = txtEmail.Text;

             // L�neas del registro
             g.DrawString("ID:", fuenteEtiqueta, Brushes.Black, margenIzq, y);
             g.DrawString(id, fuenteValor, Brushes.Black, margenIzq + 100, y);
             y += fuenteValor.GetHeight(g) + 5;

             g.DrawString("Nombre:", fuenteEtiqueta, Brushes.Black, margenIzq, y);
             g.DrawString(nombre, fuenteValor, Brushes.Black, margenIzq + 100, y);
             y += fuenteValor.GetHeight(g) + 5;

             g.DrawString("Correo:", fuenteEtiqueta, Brushes.Black, margenIzq, y);
             g.DrawString(email, fuenteValor, Brushes.Black, margenIzq + 100, y);

             // No hay m�s p�ginas
             e.HasMorePages = false;
         }*/

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            Graphics g = e.Graphics;
            Font fuenteTitulo = new Font("Arial", 18, FontStyle.Bold);
            Font fuenteEtiqueta = new Font("Arial", 12, FontStyle.Bold);
            Font fuenteValor = new Font("Arial", 12, FontStyle.Regular);
            Font fuentePie = new Font("Arial", 9, FontStyle.Italic);

            float margenIzq = e.MarginBounds.Left;
            float margenTop = e.MarginBounds.Top;
            float anchoUtil = e.MarginBounds.Width;
            float y = margenTop;


            try
            {
                Image logo = Properties.Resources.logo;
                int logoAncho = 80;
                int logoAlto = 60;

                // Calcular posici�n: derecha del margen
                float xLogo = margenIzq + anchoUtil - logoAncho;
                g.DrawImage(logo, xLogo, margenTop, logoAncho, logoAlto);

                // Bajar el contenido para no solapar el logo
                y += logoAlto + 10;
            }
            catch (Exception ex)
            {
                // Si no hay logo, sigo imprimiendo
                System.Diagnostics.Debug.WriteLine("Logo no encontrado: " + ex.Message);
            }

            //  T�TULO
            string titulo = "REGISTRO DE CLIENTE";
            SizeF tamanoTitulo = g.MeasureString(titulo, fuenteTitulo);
            float xTitulo = margenIzq + (anchoUtil - tamanoTitulo.Width) / 2;
            g.DrawString(titulo, fuenteTitulo, Brushes.Black, xTitulo, y);
            y += tamanoTitulo.Height + 25;

            //  DATOS DEL CLIENTE 
            string id = txtId.Text;
            string nombre = txtNombre.Text;
            string email = txtEmail.Text;

            g.DrawString("ID:", fuenteEtiqueta, Brushes.Black, margenIzq, y);
            g.DrawString(id, fuenteValor, Brushes.Black, margenIzq + 100, y);
            y += fuenteValor.GetHeight(g) + 8;

            g.DrawString("Nombre:", fuenteEtiqueta, Brushes.Black, margenIzq, y);
            g.DrawString(nombre, fuenteValor, Brushes.Black, margenIzq + 100, y);
            y += fuenteValor.GetHeight(g) + 8;

            g.DrawString("Correo:", fuenteEtiqueta, Brushes.Black, margenIzq, y);
            g.DrawString(email, fuenteValor, Brushes.Black, margenIzq + 100, y);
            y += 20;

            //  PIE DE P�GINA: Fecha y hora
            string fechaHora = $"Impreso el: {DateTime.Now:dd/MM/yyyy HH:mm:ss}";
            SizeF tamanoPie = g.MeasureString(fechaHora, fuentePie);
            float xPie = margenIzq + (anchoUtil - tamanoPie.Width) / 2;
            float yPie = e.MarginBounds.Bottom - tamanoPie.Height - 5; // 5 px de margen inferior

            g.DrawString(fechaHora, fuentePie, Brushes.Gray, xPie, yPie);

            e.HasMorePages = false;

            Brush brocha = new SolidBrush(Color.RoyalBlue);
            Pen lapiz = new Pen(Color.RoyalBlue, 2);
            
            Point[] triangulo = {
                new Point(100, 50), // punto superior 
                new Point(50, 100), // punto inferior izq
                new Point(150, 150) // p i d 
            };
            g.DrawPolygon(lapiz, triangulo);
            g.FillPolygon(brocha, triangulo);
            g.
        }

        private void CargarDatos()
        {
            modoNuevo = false;
            string consulta = "SELECT * FROM clientes";
            datos = conexion.ObtenerDatos(consulta);
            MostrarRegistroSegunIndice(0);
        }

        private void MostrarRegistroSegunIndice(int indice)
        {
            modoNuevo = false;
            modoEdicion = false;

            if (datos.Rows.Count == 0)
            {
                LimpiarCampos();
                lblContador.Text = "Sin registros";
                btnAnterior.Enabled = false;
                btnSiguiente.Enabled = false;
                btnEditar.Enabled = false;
                btnEliminar.Enabled = false;
                return;
            }

            if (indice < 0) indice = 0;
            if (indice >= datos.Rows.Count) indice = datos.Rows.Count - 1;

            registroActual = indice;
            DataRow fila = datos.Rows[registroActual];

            txtId.Text = fila["id"].ToString();
            txtNombre.Text = fila["nombre"].ToString();
            txtEmail.Text = fila["email"].ToString();

            lblContador.Text = $"Registro {registroActual + 1} de {datos.Rows.Count}";

            btnAnterior.Enabled = (registroActual > 0);
            btnSiguiente.Enabled = (registroActual < datos.Rows.Count - 1);
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        private void LimpiarCampos()
        {
            txtId.Clear();
            txtNombre.Clear();
            txtEmail.Clear();
        }

        private void btnCargarDatos_Click_1(object sender, EventArgs e)
        {
            CargarDatos();
        }

        private void btnSiguiente_Click_1(object sender, EventArgs e)
        {
            MostrarRegistroSegunIndice(registroActual + 1);
        }

        private void btnAnterior_Click_1(object sender, EventArgs e)
        {
            MostrarRegistroSegunIndice(registroActual - 1);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            modoNuevo = true;
            txtNombre.ReadOnly = false;
            txtEmail.ReadOnly = false;
            LimpiarCampos();
            txtNombre.Focus();

            btnAnterior.Enabled = false;
            btnSiguiente.Enabled = false;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) || string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Por favor, complete todos los campos.");
                return;
            }

            if (modoNuevo)
            {
                bool exito = conexion.InsertarCliente(txtNombre.Text, txtEmail.Text);
                if (exito)
                {
                    MessageBox.Show("Cliente insertado correctamente.");
                    txtNombre.ReadOnly = true;
                    txtEmail.ReadOnly = true;
                    CargarDatos();
                }
            }
            else if (modoEdicion)
            {
                if (!int.TryParse(txtId.Text, out int id))
                {
                    MessageBox.Show("ID inv�lido.");
                    return;
                }

                bool exito = conexion.ActualizarCliente(id, txtNombre.Text, txtEmail.Text);
                if (exito)
                {
                    MessageBox.Show("Cliente actualizado correctamente.");
                    txtNombre.ReadOnly = true;
                    txtEmail.ReadOnly = true;
                    CargarDatos();
                }
            }
            else
            {
                MessageBox.Show("No hay cambios pendientes.");
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (datos.Rows.Count == 0)
            {
                MessageBox.Show("No hay registros para editar.");
                return;
            }

            modoEdicion = true;
            txtNombre.ReadOnly = false;
            txtEmail.ReadOnly = false;
            txtNombre.Focus();

            btnAnterior.Enabled = false;
            btnSiguiente.Enabled = false;
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (datos.Rows.Count == 0)
            {
                MessageBox.Show("No hay registros para eliminar.");
                return;
            }

            if (MessageBox.Show("�Est� seguro de que desea eliminar este cliente?",
                                "Confirmar eliminaci�n",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                if (!int.TryParse(txtId.Text, out int id))
                {
                    MessageBox.Show("ID inv�lido.");
                    return;
                }

                bool exito = conexion.EliminarCliente(id);
                if (exito)
                {
                    MessageBox.Show("Cliente eliminado correctamente.");
                    CargarDatos();
                }
            }
        }


        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string criterio = txtBuscar.Text.Trim();

            if (string.IsNullOrEmpty(criterio))
            {
                CargarDatos();
                return;
            }

            datos = conexion.BuscarClientes(criterio);

            if (datos.Rows.Count == 0)
            {
                MessageBox.Show("No se encontraron clientes con ese criterio.");
                LimpiarCampos();
                lblContador.Text = "Sin resultados";
                btnEditar.Enabled = false;
                btnEliminar.Enabled = false;
                btnAnterior.Enabled = false;
                btnSiguiente.Enabled = false;
            }
            else
            {
                MostrarRegistroSegunIndice(0);
            }
        }

        private void btnVerListado_Click(object sender, EventArgs e)
        {

            FormListado listado = new FormListado();
            listado.ShowDialog(); // abro una ventana modal y bloqueo la que est� atras.

        }

        /*
         private void iMPRIMIRToolStripMenuItem_Click(object sender, EventArgs e)
 {
     // Validar que haya un cliente cargado y guardado
     if (modoNuevo || string.IsNullOrWhiteSpace(txtId.Text))
     {
         MessageBox.Show("No se puede imprimir un registro no guardado.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
         return;
     }

     // Crear y configurar el di�logo de vista previa
     using (PrintPreviewDialog printPreview = new PrintPreviewDialog())
     {
         printPreview.Document = printDocument;
         printPreview.WindowState = FormWindowState.Maximized; // Opcional: abrir maximizado
         printPreview.ShowDialog(this); // Mostrar modal sobre este formulario
     }
 }

         */

        private void iMPRIMIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Validar que haya un cliente cargado
            if (string.IsNullOrWhiteSpace(txtId.Text) && !modoNuevo)
            {
                MessageBox.Show("No hay ning�n cliente cargado para imprimir.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            PrintDialog printDialog = new PrintDialog();
            printDialog.Document = printDocument;

            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                printDocument.Print();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
