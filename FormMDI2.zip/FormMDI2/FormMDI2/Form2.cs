﻿using System;
using System.Data;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace FormMDI2
{
    public partial class Form2 : Form
    {
        private DataTable dataTable;
        private BindingSource bindingSource;
        private string archivoCsv = "datos.csv";

        public Form2()
        {
            InitializeComponent();
            this.Text = "Documento " + DateTime.Now.ToString("HH:mm:ss");
            this.StartPosition = FormStartPosition.CenterScreen;

            InicializarDataGridView();
            CargarDatosDesdeCsv();
        }

        private void InicializarDataGridView()
        {
            // Crear DataTable con columnas
            dataTable = new DataTable();
            dataTable.Columns.Add("ID", typeof(int));
            dataTable.Columns.Add("Nombre", typeof(string));
            dataTable.Columns.Add("Edad", typeof(int));

            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;

            dataGridView1.DataSource = bindingSource;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ReadOnly = false;
            dataGridView1.Columns["ID"].ReadOnly = true; // ID no editable
        }

        private void CargarDatosDesdeCsv()
        {
            if (!File.Exists(archivoCsv))
            {
                // Si no existe, creamos un archivo vacío con encabezados
                File.WriteAllText(archivoCsv, "ID,Nombre,Edad" + Environment.NewLine);
                return;
            }

            try
            {
                string[] lineas = File.ReadAllLines(archivoCsv);
                bool esPrimeraLinea = true;

                foreach (string linea in lineas)
                {
                    if (string.IsNullOrWhiteSpace(linea)) continue;

                    if (esPrimeraLinea)
                    {
                        esPrimeraLinea = false;
                        continue; // Saltar encabezado
                    }

                    string[] campos = linea.Split(',');
                    if (campos.Length == 3)
                    {
                        int id = int.TryParse(campos[0], out int idVal) ? idVal : -1;
                        string nombre = campos[1].Trim();
                        int edad = int.TryParse(campos[2], out int edadVal) ? edadVal : 0;

                        if (id != -1)
                        {
                            dataTable.Rows.Add(id, nombre, edad);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar el archivo CSV:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void GuardarDatosEnCsv()
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(archivoCsv, false, Encoding.UTF8))
                {
                    // Escribir encabezado
                    sw.WriteLine("ID,Nombre,Edad");

                    foreach (DataRow row in dataTable.Rows)
                    {
                        // Validar que no sea una fila nueva vacía (fila de nueva entrada)
                        if (row.RowState != DataRowState.Detached &&
                            (row["Nombre"] != DBNull.Value || row["Edad"] != DBNull.Value))
                        {
                            string nombre = row["Nombre"]?.ToString()?.Replace(",", "\\,") ?? "";
                            string edad = row["Edad"]?.ToString() ?? "0";
                            string id = row["ID"]?.ToString() ?? "-1";

                            // Si es una nueva fila (ID -1 o vacío), asignar nuevo ID
                            if (string.IsNullOrEmpty(id) || id == "-1")
                            {
                                id = ObtenerSiguienteId().ToString();
                                row["ID"] = id;
                            }

                            sw.WriteLine($"{id},{nombre},{edad}");
                        }
                    }
                }

                MessageBox.Show("Datos guardados correctamente en 'datos.csv'.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar el archivo CSV:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int ObtenerSiguienteId()
        {
            int maxId = 0;
            foreach (DataRow row in dataTable.Rows)
            {
                if (row["ID"] != DBNull.Value && int.TryParse(row["ID"].ToString(), out int id))
                {
                    if (id > maxId) maxId = id;
                }
            }
            return maxId + 1;
        }

        // Evento del botón Guardar
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            // Asegurarse de que la fila actual se confirme (importante si el usuario está editando)
            dataGridView1.EndEdit();
            bindingSource.EndEdit();

            GuardarDatosEnCsv();
        }

        // Botón Borrar (opcional, ya que AllowUserToDeleteRows = true permite borrar con Supr)
        private void btnBorrar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    if (!row.IsNewRow)
                    {
                        dataTable.Rows.RemoveAt(row.Index);
                    }
                }
            }
            else
            {
                MessageBox.Show("Seleccione una fila para eliminar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Botón Actualizar (solo confirma edición actual)
        private void btnActualizar_Click(object sender, EventArgs e)
        {
            dataGridView1.EndEdit();
            bindingSource.EndEdit();
            MessageBox.Show("Cambios aplicados (pendientes de guardar).", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnGuardar_Click_1(object sender, EventArgs e)
        {
            // Asegurarse de que la fila actual se confirme (importante si el usuario está editando)
            dataGridView1.EndEdit();
            bindingSource.EndEdit();

            GuardarDatosEnCsv();
        }
    }
}