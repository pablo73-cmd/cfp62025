namespace FormMDI2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.IsMdiContainer = true;
            this.Text = "Aplicaci�n MDI - PRINCIPAL";
            this.WindowState = FormWindowState.Maximized;
        }

        private void AbrirNuevoDocumento()
        {
            Form2 f = new Form2();
            f.MdiParent = this;
            f.FormClosed += (s, e) => btnAbrir.Enabled = true; // Habilita el bot�n cuando se cierre Form2
            f.Show();
            btnAbrir.Enabled = false;
        }

        private void btnAbrir_Click(object sender, EventArgs e)
        {
            AbrirNuevoDocumento();
        }
    }
}
