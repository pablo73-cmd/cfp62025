using System;
using System.Data;
using System.Windows.Forms;
namespace _290925
{


    public partial class Form1 : Form
    {
        private ConexionBD conexion;
        private DataTable datos;
        private int registroActual = 0;


        public Form1()
        {
            InitializeComponent();
            conexion = new ConexionBD();
        }


        private void CargarDatos()
        {

            string consulta = "SELECT * FROM clientes";
            datos = conexion.ObtenerDatos(consulta);

            if (datos.Rows.Count > 0)
            {
                registroActual = 0;
                MostrarRegistroActual();
            }
            else
            {
                MessageBox.Show("No hay datos en la tabla");
            }
        }


        private void MostrarRegistroActual()
        {
            if (datos.Rows.Count == 0) return;

            DataRow fila = datos.Rows[registroActual];


            txtId.Text = fila["id"].ToString();
            txtNombre.Text = fila["nombre"].ToString();
            txtEmail.Text = fila["email"].ToString();


            lblContador.Text = $"Registro {registroActual + 1} de {datos.Rows.Count}";

            btnAnterior.Enabled = (registroActual > 0);
            btnSiguiente.Enabled = (registroActual < datos.Rows.Count - 1);
        }


        private void btnSiguiente_Click(object sender, EventArgs e)
        {

        }


        private void btnAnterior_Click(object sender, EventArgs e)
        {

        }


        private void btnCargarDatos_Click(object sender, EventArgs e)
        {

        }

        private void btnCargarDatos_Click_1(object sender, EventArgs e)
        {
            CargarDatos();
        }

        private void btnSiguiente_Click_1(object sender, EventArgs e)
        {
            if (registroActual < datos.Rows.Count - 1)
            {
                registroActual++;
                MostrarRegistroActual();
            }
        }

        private void btnAnterior_Click_1(object sender, EventArgs e)
        {
            if (registroActual > 0)
            {
                registroActual--;
                MostrarRegistroActual();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
         //  CargarDatos();
        }
    }
}
