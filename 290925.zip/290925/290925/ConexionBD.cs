﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace _290925
{
    public class ConexionBD
    {
      
        private string conexion = "Server=localhost;Database=empresa2;Uid=root;Pwd=;";

       
        public DataTable ObtenerDatos(string consultaSQL)
        {
            DataTable tabla = new DataTable();
            /*
             MySqlConnection conectar = new MySqlConnection(conexion);
            conectar.Open();
            MySqlCommand comando = new MySqlCommand(consultaSQL, conectar);
            MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
            adaptador.Fill(tabla);
             */
            try
            {
                using (MySqlConnection conectar = new MySqlConnection(conexion))
                {
                    conectar.Open();
                    using (MySqlCommand comando = new MySqlCommand(consultaSQL, conectar))
                    {
                        using (MySqlDataAdapter adaptador = new MySqlDataAdapter(comando))
                        {
                            adaptador.Fill(tabla);
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error de base de datos: " + ex.Message);
            }

            return tabla;
        }
    }
}
