﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _150925
{
     class ManejadorArchivos : IManejadorArchivos
    {
        private string rutaArchivo;

        //constructor 
        public ManejadorArchivos(string nombreArchivo) {
            rutaArchivo = nombreArchivo;

        }
        public void GuardarTexto(string texto) {
            File.WriteAllText(rutaArchivo, texto);
        }
        public string LeerTexto() {
            if (Existe())
            {
                return File.ReadAllText(rutaArchivo);

            }
            else {
                return null;  // no existe 
            }
        }

        public bool Existe() {
            return File.Exists(rutaArchivo);
        }

        public void AgregarTexto(string texto) { 
        File.AppendAllText(rutaArchivo,texto +"  "+Environment.NewLine);
            Console.WriteLine("Texto agregado correctamente");
        }


    }
}
