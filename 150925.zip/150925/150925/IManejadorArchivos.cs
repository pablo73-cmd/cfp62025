﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _150925
{
     interface IManejadorArchivos
    {
        void GuardarTexto(string texto);
        string LeerTexto();
        bool Existe();
       void AgregarTexto(string texto);
    }
}
