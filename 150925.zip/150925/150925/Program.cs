﻿using System;
using System.IO;
using _150925;

// archivos 
/*
Console.WriteLine("Escriba el texto que quieras guardar");
string texto = Console.ReadLine();

string nombreArchivo = "miarchivo.txt";

File.WriteAllText(nombreArchivo, texto);

Console.WriteLine("Texto guardado en: " + nombreArchivo);
Console.ReadKey();

string nombreArchivo = @"C:\USERS\PC\Desktop\miarchivo.txt";

if (File.Exists(nombreArchivo))
{
    string contenido = File.ReadAllText(nombreArchivo);

    Console.WriteLine("Contenido del archivo.......");
    Console.WriteLine(contenido);
    Console.WriteLine("______________________");

}
else {
    Console.WriteLine("El archivo no existe");
}

/*
string nombreArchivo = "notas.txt";

while (true)
{
    Console.Clear();
    Console.WriteLine("Menu de archivos");
    Console.WriteLine("1 - Guardar Texto");
    Console.WriteLine("2 - Leer Texto");
    Console.WriteLine("3 - Salir");
    Console.WriteLine("Elegi una opción");
    string opcion = Console.ReadLine();
    switch (opcion) {
        case "1":
            Console.WriteLine("Escribe el texto");
            string texto = Console.ReadLine();
            File.WriteAllText(nombreArchivo, texto);
            Console.WriteLine(" Guardado");
            break;

        case "2":
            if (File.Exists(nombreArchivo))
            {
                string contenido = File.ReadAllText(nombreArchivo);
                Console.WriteLine(contenido);

            }
            else {
                Console.WriteLine("Aún no hay archivo");

           
            }
            break;
        case "3":
            Console.WriteLine("Salir");

            return;

        default:
            Console.WriteLine("Opción no válida");
            break;
    }
    Console.ReadKey();
}
*/

IManejadorArchivos archivo = new ManejadorArchivos("notas.txt"); //instancia (objeto) y el constructor 

while (true) {
    Console.Clear();
    Console.WriteLine("Menu de archivos");
    Console.WriteLine("1- Guardar");
    Console.WriteLine("2- Leer");
    Console.WriteLine("3- Agregar");
    Console.WriteLine("4- Salir");
    Console.WriteLine("Elige una opcion");
    string opcion = Console.ReadLine();

    switch (opcion) {
        case "1":
            Console.WriteLine("Escribe el texto");
            string texto = Console.ReadLine();
            archivo.GuardarTexto(texto); // usando el método de la clase
            break;
            case "2":
            if (archivo.Existe())
            {
                string contenido = archivo.LeerTexto(); // otro método de la clase
                Console.WriteLine(contenido);
                Console.WriteLine("-________________________________-");

            }
            else {
                Console.WriteLine("El archivo aun no existe");
            }
            break;
        case "3":
            Console.WriteLine("Agregue más texto si desea....");
            texto = Console.ReadLine();
            archivo.AgregarTexto(texto); // metodo de la clase
            break;
        
        case "4":
            Console.WriteLine("Chau!!!");
            return;



        default:
            Console.WriteLine("opcion no valida");
            break;
    }
    Console.ReadKey();

}


