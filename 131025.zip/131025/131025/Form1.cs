﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace _131025
{
    public partial class Form1 : Form
    {
        private readonly string connectionString = "server=localhost;user=root;password=;database=ejemplo_db;";
        private DataTable? dataTable;

        public Form1()
        {
            InitializeComponent();
            InitializeDataGridView();
            LoadDataFromDatabase();
        }

        private void InitializeDataGridView()
        {
            dataGridView1.AllowUserToAddRows = true;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ReadOnly = false;

            dataGridView1.CellEndEdit += OnCellEndEdit;
            dataGridView1.CellDoubleClick += OnCellDoubleClick;
        }

        private void LoadDataFromDatabase()
        {
            try
            {
                using var conn = new MySqlConnection(connectionString);
                conn.Open();
                const string query = "SELECT id, nombre, email FROM usuarios ORDER BY id";
                using var adapter = new MySqlDataAdapter(query, conn);
                dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;

                if (dataGridView1.Columns["id"] is DataGridViewColumn idColumn)
                {
                    idColumn.ReadOnly = true;
                    idColumn.Visible = true;
                }

                dataTable.RowChanged += DataTable_RowChanged;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar datos:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DataTable_RowChanged(object? sender, DataRowChangeEventArgs e)
        {
            if (e.Action != DataRowAction.Add) return;
            if (dataTable == null) return;

            // Evitar bucle: si ya tiene ID, no procesar
            if (e.Row["id"] is not DBNull && e.Row["id"] is not null) return;

            string nombre = e.Row["nombre"]?.ToString() ?? string.Empty;
            string email = e.Row["email"]?.ToString() ?? string.Empty;

            if (string.IsNullOrWhiteSpace(nombre) && string.IsNullOrWhiteSpace(email))
                return;

            try
            {
                using var conn = new MySqlConnection(connectionString);
                conn.Open();
                using var cmd = new MySqlCommand("INSERT INTO usuarios (nombre, email) VALUES (@nombre, @email)", conn);
                cmd.Parameters.AddWithValue("@nombre", string.IsNullOrWhiteSpace(nombre) ? (object)DBNull.Value : nombre);
                cmd.Parameters.AddWithValue("@email", string.IsNullOrWhiteSpace(email) ? (object)DBNull.Value : email);
                cmd.ExecuteNonQuery();

                long newId = cmd.LastInsertedId;
                e.Row["id"] = newId;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al insertar:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Row.Delete();
            }
        }

        private void OnCellEndEdit(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            if (dataGridView1.Rows[e.RowIndex].IsNewRow) return;

            var row = dataGridView1.Rows[e.RowIndex];
            if (row.DataBoundItem is not DataRowView drv) return;

            // Solo validar ID si la fila YA DEBERÍA tenerlo (es decir, no es nueva y no es DBNull)
            // Pero si es una fila existente y no tiene ID, entonces sí advertir.
            if (drv["id"] is DBNull || drv["id"] is null)
            {
                // Verificar: ¿es una fila que ya fue agregada al DataTable pero sin ID?
                // Esto solo debería pasar si hay un error grave. En la mayoría de los casos, no mostrar advertencia.
                // En su lugar, intentar guardar como NUEVA (aunque técnicamente no es IsNewRow)

                // Pero para evitar falsos positivos, mejor NO mostrar advertencia aquí.
                // El sistema de inserción (RowChanged) ya maneja el guardado.
                return;
            }

            try
            {
                int id = Convert.ToInt32(drv["id"]);
                string nombre = drv["nombre"]?.ToString() ?? string.Empty;
                string email = drv["email"]?.ToString() ?? string.Empty;

                using var conn = new MySqlConnection(connectionString);
                conn.Open();
                using var cmd = new MySqlCommand("UPDATE usuarios SET nombre = @nombre, email = @email WHERE id = @id", conn);
                cmd.Parameters.AddWithValue("@nombre", nombre);
                cmd.Parameters.AddWithValue("@email", email);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al actualizar:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OnCellDoubleClick(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            if (dataGridView1.Rows[e.RowIndex].IsNewRow) return;

            var result = MessageBox.Show(
                "¿Desea eliminar este registro?\nEsta acción no se puede deshacer.",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (result != DialogResult.Yes) return;

            var row = dataGridView1.Rows[e.RowIndex];
            if (row.DataBoundItem is not DataRowView drv) return;

            if (drv["id"] is DBNull || drv["id"] is null)
            {
                MessageBox.Show("No se puede eliminar un registro sin ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                int id = Convert.ToInt32(drv["id"]);
                using var conn = new MySqlConnection(connectionString);
                conn.Open();
                using var cmd = new MySqlCommand("DELETE FROM usuarios WHERE id = @id", conn);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();

                dataTable?.Rows.RemoveAt(e.RowIndex);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
        }
    }
}