﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_9_25
{
    static class Herramientas
    {

        public static void Saludar()
        {
            Console.WriteLine("Bienvenido al sistema");

        }
        public static void MostrarFecha()
        {
            Console.WriteLine("Hoy es: " + DateTime.Now.ToShortDateString());
        }

        public static string Saludar2(string saludo)
        {
            return saludo;


        }

        public static void Saludar3(string saludo)
        {
            Console.WriteLine($"Bienvenido {saludo} al sistema");
        }
        

    }
}
