﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace _3_9_25
{
    class AutoDeportivo : Auto
    {
        private bool TurboActivado { get; set; }

        public AutoDeportivo(string marca, string modelo):base(marca, modelo) {
            TurboActivado = false; 
        }

        // Polimorfismo. Sobreescribo el metodo Arrancar

        public override void Arrancar()
        {
            Console.WriteLine("El auto de marca  " + Marca + " y modelo " + Modelo + " enciende en modo Deportivo");
        }

        //metodo especifico para el auto deportivo

        public void ActivarTurbo() {
            TurboActivado = true;
            Console.WriteLine("Turbo activado - Aceleración máxima");
            Acelerar(200);
        }


    }
}
