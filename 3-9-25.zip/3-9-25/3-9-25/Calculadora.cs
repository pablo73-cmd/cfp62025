﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_9_25
{
     class Calculadora
    {
        // método estático: no necesitamos crear un objeto 

        public static double Sumar(double a, double b) {
            return a + b;
        }

        public static double Multiplicar(double a, double b)
        {
            return a * b;
        }
    }
}
