﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_9_25
{
     class Contador
    {
        static int contador = 0;
        public static void Contar() {
             
            contador++;
            Console.WriteLine("Veces que se llamo a contar " + contador);

        }
    }
}
