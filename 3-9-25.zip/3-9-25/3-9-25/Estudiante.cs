﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_9_25
{
     class Estudiante
    {
        public string Nombre;
        public static int TotalEstudiantes = 0; // Atributo estático 

        public Estudiante(string nombre) { 
        Nombre = nombre;
            TotalEstudiantes++; // Cada vez que se crea un estudiante suma 1 
        }


    }
}
