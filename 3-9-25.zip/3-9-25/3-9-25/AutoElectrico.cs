﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace _3_9_25
{
     class AutoElectrico : Auto
    {
        private double NivelBateria { get; set;  } // 0 a 100

        public AutoElectrico(string marca, string modelo, double bateria) : base(marca, modelo) {
            NivelBateria = bateria;

        }

        // Polimorfismo 
        public override void Arrancar()
        {
            if (NivelBateria > 0)
            {
                Console.WriteLine("El auto arranca en modo silencioso...");
            }
            else
            {
                Console.WriteLine("El auto necesita recarga");

            }

            //método específico para el eléctrico 
        }
            public void CargarBateria(int porcentaje)
        {
            if (porcentaje > 0) {
                NivelBateria += porcentaje;
                if (NivelBateria > 100)
                {
                    NivelBateria = 100;
                    Console.WriteLine("Bateria Cargada...");
                }
            }
        }



        }
    }
