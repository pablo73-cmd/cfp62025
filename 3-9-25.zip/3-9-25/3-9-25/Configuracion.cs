﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_9_25
{
     class Configuracion
    {
        public const double IVA = 0.21;
        public static string Moneda = "Pesos";

        static Configuracion() { 
        
        }



    }
}
