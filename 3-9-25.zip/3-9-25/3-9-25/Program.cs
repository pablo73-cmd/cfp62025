﻿using _3_9_25;

Console.WriteLine("Total de estudiantes: " + Estudiante.TotalEstudiantes );

Estudiante estudiante01 = new Estudiante("Juan");
Estudiante estudiante02 = new Estudiante("Pedro");
Estudiante estudiante03 = new Estudiante("Maria");

Console.WriteLine("Total de estudiantes: " + Estudiante.TotalEstudiantes);


Console.ReadKey();

double resultado = Calculadora.Sumar(5, 3);
Console.WriteLine("El resultado de sumar es : " + resultado);
Console.WriteLine("La multiplicación da: " + Calculadora.Multiplicar(5, 3));

Console.ReadKey();

Herramientas.Saludar();
Herramientas.MostrarFecha();
Console.WriteLine(Herramientas.Saludar2("HOLA QUE TAL"));
Console.WriteLine(Herramientas.Saludar2("En chino se dice NI HAO"));
Herramientas.Saludar3(estudiante03.Nombre);

Console.ReadKey();

Console.WriteLine("Nombre del banco: " + Banco.NombreBanco);
Console.WriteLine("Interes anual " + Banco.InteresAnual + " % ");

Console.WriteLine("Gracias por usar " + Banco.NombreBanco);

Console.ReadKey();

Console.WriteLine("IVA " + Configuracion.IVA * 100 + " % ");
Console.WriteLine("Moneda usada: " + Configuracion.Moneda);

Console.ReadKey();

Contador.Contar();
Contador.Contar();
Contador.Contar();
Contador.Contar();

Console.ReadKey();

Console.WriteLine(" Bienvenido a la concesionaria....");

Auto.MostrarInfoGral();
Console.WriteLine("Total de autos creados: " + Auto.TotalAutosCreados);
AutoDeportivo ferrari = new AutoDeportivo("Ferrari", "F32");
AutoElectrico tesla = new AutoElectrico("Tesla", "Modelo 3", 96);
Console.WriteLine("Total de autos creados: " + Auto.TotalAutosCreados);
ferrari.Arrancar();
ferrari.Acelerar(40);
ferrari.ActivarTurbo();
ferrari.Frenar();

Console.WriteLine("------");

tesla.Arrancar();
tesla.Acelerar(30);
tesla.CargarBateria(10);
tesla.Frenar();
tesla.Arrancar();

Console.WriteLine("---------");

ferrari.mostrarDatos();
tesla.mostrarDatos();

Console.WriteLine("Total de autos creados en el programa" + Auto.TotalAutosCreados);


Console.ReadKey();
