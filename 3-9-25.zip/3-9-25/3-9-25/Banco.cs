﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_9_25
{
     class Banco
    {
        public static string NombreBanco;
        public static int InteresAnual;

        //Constructor Estático . Se ejecuta 1 sola vez 

        static Banco() {
            NombreBanco = " Banco Ciudad ";
            InteresAnual = 3;
            Console.WriteLine(" El banco: " + NombreBanco + " tiene un interes anual de " + InteresAnual);
        
        }

    }
}
