﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_9_25
{
  class Auto
    {
        // atributos encapsulados 
        public string Marca { get; set; }
        public string Modelo { get; set; }
        protected int Velocidad { get; set; }

        // atributo estático - Compartido por todos los autos 

        public static int TotalAutosCreados = 0;

        // método estático - No necesita objeto para funcionar 

        public static void MostrarInfoGral() {
            Console.WriteLine("Todos los autos tienen 4 ruedas");
        
        }

        // Constructor 

        public Auto(string marca, string modelo) {
            Marca = marca;
            Modelo = modelo;
            Velocidad = 0;
            TotalAutosCreados++; // Cada auto nuevo que generemos suma 1 

        }

        // Métodos normales -- Pueden ser modificados por futuros hijos 

        public virtual void Arrancar() {
            Console.WriteLine("El auto de marca: " + Marca + " y modelo " + Modelo + " está arrancado ");
        }

        public void Acelerar(int incremento) {
            Velocidad += incremento;
            Console.WriteLine("El auto acelero a velocidad " + Velocidad);
        }

        public void Frenar() {
            Velocidad = 0;
            Console.WriteLine("El auto se ha detenido");
        }

        // mostrar datos del auto 


        public void mostrarDatos()
        {
            Console.WriteLine("La marca es  " + Marca + " El modelo es " + Modelo + "la velocidad es : " + Velocidad);

        }



    }
}
