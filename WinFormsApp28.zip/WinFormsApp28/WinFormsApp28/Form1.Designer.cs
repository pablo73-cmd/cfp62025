﻿namespace WinFormsApp28
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            pic_arbol = new PictureBox();
            btn_mostrar_ocultar = new Button();
            txt_arbol = new TextBox();
            txt_score = new TextBox();
            lst_imagenes = new ListBox();
            pic_personas = new PictureBox();
            cmb_imagenes = new ComboBox();
            chk_imagenes = new CheckedListBox();
            chk_news = new CheckBox();
            dt_fecha = new DateTimePicker();
            btn_ventana = new Button();
            ((System.ComponentModel.ISupportInitialize)pic_arbol).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pic_personas).BeginInit();
            SuspendLayout();
            // 
            // pic_arbol
            // 
            pic_arbol.Image = (Image)resources.GetObject("pic_arbol.Image");
            pic_arbol.Location = new Point(52, 51);
            pic_arbol.Name = "pic_arbol";
            pic_arbol.Size = new Size(205, 152);
            pic_arbol.SizeMode = PictureBoxSizeMode.StretchImage;
            pic_arbol.TabIndex = 0;
            pic_arbol.TabStop = false;
            pic_arbol.Visible = false;
            // 
            // btn_mostrar_ocultar
            // 
            btn_mostrar_ocultar.Location = new Point(296, 108);
            btn_mostrar_ocultar.Name = "btn_mostrar_ocultar";
            btn_mostrar_ocultar.Size = new Size(117, 23);
            btn_mostrar_ocultar.TabIndex = 1;
            btn_mostrar_ocultar.Text = "mostrar";
            btn_mostrar_ocultar.UseVisualStyleBackColor = true;
            btn_mostrar_ocultar.Click += btn_mostrar_ocultar_Click;
            btn_mostrar_ocultar.KeyPress += btn_mostrar_ocultar_KeyPress;
            // 
            // txt_arbol
            // 
            txt_arbol.Location = new Point(54, 24);
            txt_arbol.Name = "txt_arbol";
            txt_arbol.Size = new Size(203, 23);
            txt_arbol.TabIndex = 2;
            // 
            // txt_score
            // 
            txt_score.Location = new Point(688, 12);
            txt_score.Name = "txt_score";
            txt_score.ReadOnly = true;
            txt_score.Size = new Size(52, 23);
            txt_score.TabIndex = 3;
            txt_score.Text = "0";
            // 
            // lst_imagenes
            // 
            lst_imagenes.FormattingEnabled = true;
            lst_imagenes.ItemHeight = 15;
            lst_imagenes.Items.AddRange(new object[] { "Arbol", "Personas" });
            lst_imagenes.Location = new Point(668, 76);
            lst_imagenes.Name = "lst_imagenes";
            lst_imagenes.Size = new Size(120, 34);
            lst_imagenes.TabIndex = 4;
            lst_imagenes.SelectedIndexChanged += lst_imagenes_SelectedIndexChanged;
            // 
            // pic_personas
            // 
            pic_personas.Image = (Image)resources.GetObject("pic_personas.Image");
            pic_personas.Location = new Point(52, 220);
            pic_personas.Name = "pic_personas";
            pic_personas.Size = new Size(205, 131);
            pic_personas.SizeMode = PictureBoxSizeMode.StretchImage;
            pic_personas.TabIndex = 5;
            pic_personas.TabStop = false;
            pic_personas.Visible = false;
            // 
            // cmb_imagenes
            // 
            cmb_imagenes.FormattingEnabled = true;
            cmb_imagenes.Items.AddRange(new object[] { "arbol", "personas" });
            cmb_imagenes.Location = new Point(671, 136);
            cmb_imagenes.Name = "cmb_imagenes";
            cmb_imagenes.Size = new Size(121, 23);
            cmb_imagenes.TabIndex = 6;
            cmb_imagenes.SelectedIndexChanged += cmb_imagenes_SelectedIndexChanged;
            // 
            // chk_imagenes
            // 
            chk_imagenes.CheckOnClick = true;
            chk_imagenes.FormattingEnabled = true;
            chk_imagenes.Items.AddRange(new object[] { "Arbol", "Personas" });
            chk_imagenes.Location = new Point(671, 196);
            chk_imagenes.Name = "chk_imagenes";
            chk_imagenes.Size = new Size(120, 94);
            chk_imagenes.TabIndex = 7;
            chk_imagenes.SelectedIndexChanged += chk_imagenes_SelectedIndexChanged;
            // 
            // chk_news
            // 
            chk_news.AutoSize = true;
            chk_news.Checked = true;
            chk_news.CheckState = CheckState.Checked;
            chk_news.Location = new Point(296, 196);
            chk_news.Name = "chk_news";
            chk_news.Size = new Size(178, 19);
            chk_news.TabIndex = 8;
            chk_news.Text = "Desea suscribir al newsletter?";
            chk_news.UseVisualStyleBackColor = true;
            chk_news.CheckedChanged += chk_news_CheckedChanged;
            // 
            // dt_fecha
            // 
            dt_fecha.Location = new Point(418, 37);
            dt_fecha.Name = "dt_fecha";
            dt_fecha.Size = new Size(200, 23);
            dt_fecha.TabIndex = 9;
            dt_fecha.ValueChanged += dt_fecha_ValueChanged;
            // 
            // btn_ventana
            // 
            btn_ventana.Location = new Point(528, 215);
            btn_ventana.Name = "btn_ventana";
            btn_ventana.Size = new Size(122, 23);
            btn_ventana.TabIndex = 10;
            btn_ventana.Text = "abrir ventana";
            btn_ventana.UseVisualStyleBackColor = true;
            btn_ventana.Click += btn_ventana_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btn_ventana);
            Controls.Add(dt_fecha);
            Controls.Add(chk_news);
            Controls.Add(chk_imagenes);
            Controls.Add(cmb_imagenes);
            Controls.Add(pic_personas);
            Controls.Add(lst_imagenes);
            Controls.Add(txt_score);
            Controls.Add(txt_arbol);
            Controls.Add(btn_mostrar_ocultar);
            Controls.Add(pic_arbol);
            Name = "Form1";
            Text = "Aplicacion 2.0";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pic_arbol).EndInit();
            ((System.ComponentModel.ISupportInitialize)pic_personas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pic_arbol;
        private Button btn_mostrar_ocultar;
        private TextBox txt_arbol;
        private TextBox txt_score;
        private ListBox lst_imagenes;
        private PictureBox pic_personas;
        private ComboBox cmb_imagenes;
        private CheckedListBox chk_imagenes;
        private CheckBox chk_news;
        private DateTimePicker dt_fecha;
        private Button btn_ventana;
    }
}
