using System.Net.Sockets;

namespace WinFormsApp28
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int score = 0;
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_mostrar_ocultar_Click(object sender, EventArgs e)
        {



            if (pic_arbol.Visible == false)
            {
                score = score + 1;
                txt_score.Text = score.ToString();
                pic_arbol.Visible = true;
                btn_mostrar_ocultar.Text = "ocultar";
                txt_arbol.ReadOnly = true;
                txt_arbol.Text = "Esto es un arbol";

            }
            else
            {
                score = 0;
                pic_arbol.Visible = false;
                btn_mostrar_ocultar.Text = "mostrar";
                txt_arbol.ReadOnly = true;
                txt_score.Text = score.ToString();
                txt_arbol.Text = "";
            }
        }

        private void btn_mostrar_ocultar_KeyPress(object sender, KeyPressEventArgs e)
        {
            MessageBox.Show("Hola");
        }

        private void lst_imagenes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lst_imagenes.SelectedItem.ToString() == "Personas")
            {
                pic_personas.Visible = true;
                pic_arbol.Visible = false;
            }
            else
            {
                pic_personas.Visible = false;
                pic_arbol.Visible = true;
            }

        }

        private void cmb_imagenes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_imagenes.SelectedItem.ToString() == "personas")
            {
                pic_personas.Visible = true;
                pic_arbol.Visible = false;

            }
            else
            {
                pic_personas.Visible = false;
                pic_arbol.Visible = true;


            }
        }

        private void chk_imagenes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (chk_imagenes.SelectedItem.ToString() == "Personas")
            {
                pic_personas.Visible = true;
                pic_arbol.Visible = false;
            }
            else
            {

                pic_personas.Visible = false;
                pic_arbol.Visible = true;
            }
        }

        private void chk_news_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_news.Checked == false)
            {

                DialogResult resultado = MessageBox.Show("Se va a perder", "Alerta", MessageBoxButtons.RetryCancel, MessageBoxIcon.Information);
                if (resultado == DialogResult.Retry)
                {
                    MessageBox.Show("Elegiste revertir");
                }
                else if (resultado == DialogResult.Cancel)
                {
                    MessageBox.Show("Elegiste cancelar");
                }
                else
                {
                    //  MessageBox.Show("Elegiste cancelar");
                }
            }
        }

        private void dt_fecha_ValueChanged(object sender, EventArgs e)
        {
            txt_arbol.Text = dt_fecha.Value.DayOfWeek.ToString();
            if (txt_arbol.Text == "Thursday")
            {
                txt_arbol.Text = "Jueves";
            }
        }

        private void btn_ventana_Click(object sender, EventArgs e)
        {
            
            Form formulario2 = new Form2();
            formulario2.Show();
            this.Hide();
        }
    }
}
