﻿namespace WinFormsApp28
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_cerrar = new Button();
            menuStrip1 = new MenuStrip();
            cerrarToolStripMenuItem = new ToolStripMenuItem();
            cerrarToolStripMenuItem1 = new ToolStripMenuItem();
            abrirFormulario1ToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // btn_cerrar
            // 
            btn_cerrar.Location = new Point(633, 50);
            btn_cerrar.Name = "btn_cerrar";
            btn_cerrar.Size = new Size(130, 23);
            btn_cerrar.TabIndex = 0;
            btn_cerrar.Text = "volver";
            btn_cerrar.UseVisualStyleBackColor = true;
            btn_cerrar.Click += btn_cerrar_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { cerrarToolStripMenuItem, abrirFormulario1ToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 1;
            menuStrip1.Text = "menuStrip1";
            // 
            // cerrarToolStripMenuItem
            // 
            cerrarToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { cerrarToolStripMenuItem1 });
            cerrarToolStripMenuItem.Name = "cerrarToolStripMenuItem";
            cerrarToolStripMenuItem.Size = new Size(51, 20);
            cerrarToolStripMenuItem.Text = "Iniicio";
            cerrarToolStripMenuItem.Click += cerrarToolStripMenuItem_Click;
            // 
            // cerrarToolStripMenuItem1
            // 
            cerrarToolStripMenuItem1.Name = "cerrarToolStripMenuItem1";
            cerrarToolStripMenuItem1.Size = new Size(180, 22);
            cerrarToolStripMenuItem1.Text = "Cerrar";
            cerrarToolStripMenuItem1.Click += cerrarToolStripMenuItem1_Click;
            // 
            // abrirFormulario1ToolStripMenuItem
            // 
            abrirFormulario1ToolStripMenuItem.Name = "abrirFormulario1ToolStripMenuItem";
            abrirFormulario1ToolStripMenuItem.Size = new Size(115, 20);
            abrirFormulario1ToolStripMenuItem.Text = "Abrir Formulario 1";
            abrirFormulario1ToolStripMenuItem.Click += abrirFormulario1ToolStripMenuItem_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btn_cerrar);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form2";
            Text = "Form2";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_cerrar;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem cerrarToolStripMenuItem;
        private ToolStripMenuItem cerrarToolStripMenuItem1;
        private ToolStripMenuItem abrirFormulario1ToolStripMenuItem;
    }
}